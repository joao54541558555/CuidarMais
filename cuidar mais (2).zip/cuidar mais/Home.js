
    // Scroll suave e mudança de link ativo
    const links = document.querySelectorAll('nav a');
    function scrollToSection(id) {
      document.getElementById(id).scrollIntoView({ behavior: 'smooth' });
    }
    links.forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        const target = link.getAttribute('href').substring(1);
        scrollToSection(target);
        links.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
      });
    });
